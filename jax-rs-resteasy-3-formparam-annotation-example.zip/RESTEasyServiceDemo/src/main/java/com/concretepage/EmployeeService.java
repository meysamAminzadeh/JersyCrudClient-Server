package com.concretepage;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.annotations.Form;
import org.jboss.resteasy.annotations.providers.jackson.Formatted;
 
@Path("/manage")
public class EmployeeService {
    @POST
    @Path("/save")
    @Consumes("application/x-www-form-urlencoded")
    @Produces("application/json")
    @Formatted
    public Response saveEmp(@FormParam("id") String id, @FormParam("name") String name, 
    		                                                   @FormParam("company") String company) {
    	Map<String,String> map = new HashMap<String,String>();
    	map.put("result", "Data Saved 1");    	
    	map.put("id", id);
    	map.put("name", name);
    	map.put("company", company);
        return Response.ok(map).build();
    }
    @POST
    @Path("/saveform")
    @Consumes("application/x-www-form-urlencoded")
    @Produces("application/json")
    @Formatted
    public Response saveEmpForm(@Form EmpForm form) {
    	Map<String,String> map = new HashMap<String,String>();
    	map.put("result", "Data Saved 2");
    	map.put("id", form.getId());
    	map.put("name", form.getName());
    	map.put("company", form.getCompany());
        return Response.ok(map).build();
    }
}

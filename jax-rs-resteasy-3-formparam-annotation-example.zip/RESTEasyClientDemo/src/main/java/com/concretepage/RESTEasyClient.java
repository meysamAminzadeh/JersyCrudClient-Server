package com.concretepage;

import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.jboss.resteasy.client.jaxrs.ResteasyClient;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.jboss.resteasy.client.jaxrs.ResteasyWebTarget;

public class RESTEasyClient {
	public static void main(String[] args) {
		ResteasyClient client = new ResteasyClientBuilder().build();
        ResteasyWebTarget target = client.target("http://localhost:8080/resteasyservice-1/employee/manage/saveform");
        Form form = new Form();
        form.param("id", "122").param("name", "Atul").param("company", "BBB");
        Entity<Form> entity = Entity.form(form);
        Response response = target.request(MediaType.APPLICATION_JSON).post(entity);
        String value = response.readEntity(String.class);
        System.out.println(value);
        response.close();  

        
	}
}
